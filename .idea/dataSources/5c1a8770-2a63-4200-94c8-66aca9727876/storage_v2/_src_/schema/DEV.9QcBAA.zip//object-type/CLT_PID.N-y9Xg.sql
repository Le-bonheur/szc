create TYPE CLT_PID AS OBJECT
(
  CLT_PID varchar2(100)
)
/

